package io.spring.batch.multiple.database.usermodel;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "USER_TB")
public class User {
	

	public User(int id, String userName) {
		super();
		this.id = id;
		this.userName = userName;
	}
	@Id
	private int id;
	private String userName;
}
