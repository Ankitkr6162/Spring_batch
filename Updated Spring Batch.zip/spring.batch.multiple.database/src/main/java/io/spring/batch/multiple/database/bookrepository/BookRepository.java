package io.spring.batch.multiple.database.bookrepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import io.spring.batch.multiple.database.bookmodel.Book;




@Repository
public interface BookRepository extends JpaRepository<Book, Integer>{

}
