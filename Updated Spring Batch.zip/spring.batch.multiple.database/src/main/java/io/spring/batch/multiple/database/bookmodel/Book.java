package io.spring.batch.multiple.database.bookmodel;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "BOOK_TB")
public class Book {

	

	public Book(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	@Id
	private int id;
	private String name;
}
